the project done using html,css and javascript

to open the project 
just open (poject.html) file